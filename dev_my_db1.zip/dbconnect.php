
<?php

/*
 * define('HOST','localhost');
define('USER', 'root');
define('PASS','');
define('DB','santalert');
$con = mysqli_connect(HOST,USER,PASS,DB);
  if (!$con){
	 die("Error in connection" . mysqli_connect_error()) ;
  }



define('HOST','localhost');
define('USER', 'habite1012_santa');
define('PASS','uM1Gb%_kn7%j');
define('DB','habite1012_santalert');
$con = mysqli_connect(HOST,USER,PASS,DB);

if (!$con){
    die("Error in connection" . mysqli_connect_error()) ;
}
*/

define('HOST','localhost');
define('USER', 'habitech_sant');
define('PASS','?bi6JRpHLV.W');
define('DB','habitech_sant-alert');
$con = mysqli_connect(HOST,USER,PASS,DB);

if (!$con){
    die("Error in connection" . mysqli_connect_error()) ;
}

?>
